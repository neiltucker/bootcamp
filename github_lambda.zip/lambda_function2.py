def lambda_handler(event, context):
    
    htmlcode = '''<html>
    <head><title>Personal Website Template</title></head>
    <body>
    <h1><u>My Website</u></h1>
    <p><h2>Hello World!</h2></p>
    <p>Welcome to my website.</p>
    </body>
    </html>'''
    
    response = {
        'statusCode': 200,
        'headers': {"Content-Type": "text/html",},
        'body': htmlcode
    }
    
    return response