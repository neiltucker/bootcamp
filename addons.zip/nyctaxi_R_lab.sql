-- NYCTaxi Lab: Using R in SQL Server
-- SQL Server Machine Learning Services must already be installed
-- External scriptures should be enabled (e.g., EXECUTE sp_configure  'external scripts enabled', 1; RECONFIGURE WITH OVERRIDE;)
-- Make sure the NYCTaxi_Sample database is already installed (c:\classfiles\tools\nyctaxi_install.ps1)

USE NYCTaxi_Sample
GO

-- Verify R script execution
EXECUTE sp_execute_external_script
@language = N'R',
@script = N'
x <- 10
y <- 20

z <- x * y
print(z)
'

GO

-- List R Version and Packages
EXECUTE sp_execute_external_script @language = N'R', @script = N'print(R.version)'
GO
EXECUTE sp_execute_external_script @language=N'R', @script = N'str(OutputDataSet);
packagematrix <- installed.packages();
Name <- packagematrix[,1];
Version <- packagematrix[,3];
OutputDataSet <- data.frame(Name, Version);',
@input_data_1 = N'
  '
WITH RESULT SETS ((PackageName nvarchar(250), PackageVersion nvarchar(max) ))
GO

-- Query nyctaxi_sample table using T-SQL
SELECT top(5) medallion FROM nyctaxi_sample
GO
SELECT COUNT(*) as [Number of Rows] FROM nyctaxi_sample
GO
SELECT DISTINCT [Passenger_Count], ROUND (SUM ([fare_amount]),0) as [Total_Fares], ROUND (AVG ([fare_amount]),0) as [Average_Fares]
FROM nyctaxi_sample
GROUP BY [Passenger_Count]
ORDER BY  [Average_Fares] 
GO

-- Query nyctaxi_sample table using R
EXECUTE sp_execute_external_script @language = N'R', @script = N'OutputDataSet <- InputDataSet;'
, @input_data_1 = N'SELECT top(5) medallion FROM nyctaxi_sample;'
GO
EXECUTE sp_execute_external_script @language = N'R', @script = N'OutputDataSet <- InputDataSet;'
, @input_data_1 = N'SELECT COUNT(*) as [Number of Rows] FROM nyctaxi_sample;'
WITH RESULT SETS(([Number of Rows] NVARCHAR(50) NOT NULL));
GO
EXECUTE sp_execute_external_script @language = N'R', @script = N'OutputDataSet <- InputDataSet;'
, @input_data_1 = N'SELECT DISTINCT [Passenger_Count], ROUND (SUM ([fare_amount]),0) as [Total_Fares], ROUND (AVG ([fare_amount]),0) as [Average_Fares]
FROM nyctaxi_sample
GROUP BY [Passenger_Count]
ORDER BY  [Average_Fares];'
WITH RESULT SETS(([Passenger Count] INT, [Total Fares] INT, [Average Fares] INT));
GO

-- Use R modules
-- Random numbers
EXEC sp_execute_external_script
 @language = N'R',
 @script = N'OutputDataSet <- as.data.frame( runif(5,100,200) );'
 WITH RESULT SETS(([Random Numbers] FLOAT));
 GO

-- Create R Stored Procedures
DROP PROCEDURE IF EXISTS lsp_radd
GO
CREATE PROCEDURE lsp_radd (@x int, @y int)
AS
    EXEC sp_execute_external_script    
      @language = N'R'    
    , @script = N' OutputDataSet <- data.frame(SumRes = sum(x_r, y_r));'    
    , @input_data_1 = N'   ;' 
    , @params = N' @x_r int, @y_r int'  
    , @x_r = @x
    , @y_r = @y
    WITH RESULT SETS (([Sum of X and Y] int NOT NULL)); 
GO
EXECUTE lsp_radd @x = 25, @y = 100
GO

DROP PROCEDURE IF EXISTS lsp_medallion
GO
CREATE PROCEDURE lsp_medallion
AS
EXECUTE sp_execute_external_script @language = N'R', @script = N'OutputDataSet <- InputDataSet;'
, @input_data_1 = N'SELECT top(10) medallion FROM nyctaxi_sample;'
WITH RESULT SETS(([Medallions] NVARCHAR(MAX)));
GO
EXECUTE lsp_medallion

