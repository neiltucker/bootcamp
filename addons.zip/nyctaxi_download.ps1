# Download NYCTaxi_Sample Database
Write-Output "Download NYCTaxi_Sample files"
$ToolsFolder = "C:\Classfiles\Tools\"
$NYCTaxi_SampleDB = "NYCTaxi_Sample.bak"
$NYCTaxi_SampleDBPATH = $ToolsFolder + $NYCTaxi_SampleDB 
$NYCTaxi_SampleURL = "https://aka.ms/sqlmldocument/NYCTaxi_Sample.bak"

IF (-not(Test-Path $ToolsFolder)) {New-Item -ItemType Directory -Path $ToolsFolder}

Invoke-WebRequest -Uri $NYCTaxi_SampleURL -OutFile $NYCTaxi_SampleDBPATH
Start-Sleep 5
IF (Test-Path $NYCTaxi_SampleDBPATH) {
Write-Output "NYCTaxi_Sample DB downloaded successfully."}






