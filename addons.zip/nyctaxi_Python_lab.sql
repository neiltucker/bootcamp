-- NYCTaxi Lab: Using Python in SQL Server
-- SQL Server Machine Learning Services must already be installed
-- External scriptures should be enabled (e.g., EXECUTE sp_configure  'external scripts enabled', 1; RECONFIGURE WITH OVERRIDE;)
-- Make sure the NYCTaxi_Sample database is already installed (c:\classfiles\tools\nyctaxi_install.ps1)

USE NYCTaxi_Sample
GO
-- Verify Python script execution
EXECUTE sp_execute_external_script @language = N'Python'
 , @script = N'
x = 10
y = 20
z = x * y
print(z)
'
GO
-- List Python Packages
EXECUTE sp_execute_external_script 
@language = N'Python', @script = N'
import pandas as pd
import numpy as np
import pkg_resources
dists = [str(d) for d in pkg_resources.working_set]
OutputDataSet = pandas.DataFrame(dists)
'
WITH RESULT SETS(([Package] NVARCHAR(max)))
GO

-- Query nyctaxi_sample table using T-SQL
SELECT top(5) medallion FROM nyctaxi_sample
GO
SELECT COUNT(*) as [Number of Rows] FROM nyctaxi_sample
GO
SELECT DISTINCT [Passenger_Count], ROUND (SUM ([fare_amount]),0) as [Total_Fares], ROUND (AVG ([fare_amount]),0) as [Average_Fares]
FROM nyctaxi_sample
GROUP BY [Passenger_Count]
ORDER BY  [Average_Fares] 
GO

-- Query nyctaxi_sample table using Python
EXECUTE sp_execute_external_script 
	@language = N'Python'
    , @script = N'OutputDataSet = InputDataSet;'
    , @input_data_1 = N'SELECT top(5) medallion FROM nyctaxi_sample;'
	WITH RESULT SETS(([Medallion] NVARCHAR(50)));
GO
EXECUTE sp_execute_external_script 
	@language = N'Python'
    , @script = N'OutputDataSet = InputDataSet;'
    , @input_data_1 = N'SELECT COUNT(*) as [Number of Rows] FROM nyctaxi_sample;'
	WITH RESULT SETS(([Rows] INT));
GO
EXECUTE sp_execute_external_script 
	@language = N'Python'
    , @script = N'OutputDataSet = InputDataSet;'
    , @input_data_1 = N'SELECT DISTINCT [Passenger_Count], ROUND (SUM ([fare_amount]),0) as [Total_Fares], ROUND (AVG ([fare_amount]),0) as [Average_Fares] FROM nyctaxi_sample GROUP BY [Passenger_Count] ORDER BY  [Average_Fares];'
	WITH RESULT SETS(([Passenger Count] INT, [Total Fares] INT, [Average Fares] INT));
GO

-- Use Python modules
-- Random data
EXECUTE sp_execute_external_script @language = N'Python'
, @script = N'
import numpy as np
import pandas as pd
random_integers = np.random.randint(0, 100,10);
OutputDataSet = pd.DataFrame(random_integers)
'
    , @input_data_1 = N'   ;'
WITH RESULT SETS(([Random Integers] FLOAT NOT NULL));
GO
-- Employee data
EXECUTE sp_execute_external_script @language = N'Python'
, @script = N'
import numpy as np
import pandas as pd
OutputDataSet = pd.read_csv(''c:/classfiles/tools/employees.csv'');
'
GO
EXECUTE sp_execute_external_script @language = N'Python'
, @script = N'
import numpy as np
import pandas as pd
OutputDataSet = pd.read_csv(''c:/classfiles/tools/employees.csv'',usecols=[''EmployeeID'']);
'
    , @input_data_1 = N'   ;'
WITH RESULT SETS(([EmployeeID] NVARCHAR(MAX) NOT NULL));
GO
-- Sales data
EXECUTE sp_execute_external_script @language = N'Python'
, @script = N'
import numpy as np
import pandas as pd
OutputDataSet = pd.read_csv(''c:/classfiles/tools/sales.csv'');
'
    , @input_data_1 = N'   ;'
WITH RESULT SETS((
[SalesID] NVARCHAR(MAX) NOT NULL,
[CustomerID] NVARCHAR(MAX) NOT NULL,
[SalesRepID] NVARCHAR(MAX) NOT NULL,
[Sales] NVARCHAR(MAX) NOT NULL,
[Surcharge] NVARCHAR(MAX) NOT NULL,
[Total] NVARCHAR(MAX) NOT NULL,
[DateOfSale] NVARCHAR(MAX) NOT NULL
));
GO

-- Create a Python Stored Procedure
DROP PROCEDURE IF EXISTS lsp_customers;
GO
CREATE PROCEDURE [dbo].[lsp_customers]
AS
BEGIN
EXECUTE sp_execute_external_script @language = N'Python'
, @script = N'import pandas as pd
df = pd.read_csv(''c:/classfiles/tools/employees.csv'')
OutputDataSet = df'
END
GO

-- Execute the Procedure
EXECUTE lsp_customers 

