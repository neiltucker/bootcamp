USE master
GO
RESTORE DATABASE NYCTaxi_Sample
FROM  DISK = N'C:\Classfiles\tools\nyctaxi_sample.bak' 
WITH RECOVERY,  
MOVE 'NYCTaxi_Sample' TO 'C:\NYCTaxi\NYCTaxi_Sample.mdf',   
MOVE 'NYCTaxi_Sample_Log' TO 'C:\NYCTaxi\NYCTaxi_Sample_0.ldf';
GO
USE NYCTaxi_Sample
GO
ALTER AUTHORIZATION ON DATABASE::[NYCTaxi_Sample] TO [sa]
GO